package cn.gzhu.wallet.activity;

import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.xiasuhuei321.loadingdialog.view.LoadingDialog;

import cn.gzhu.wallet.ActivityCollector;
import cn.gzhu.wallet.FileHelper;
import cn.gzhu.wallet.KeyStoreUtil;
import cn.gzhu.wallet.R;
import cn.gzhu.wallet.manager.InitWalletManager;
import cn.gzhu.wallet.model.HLWallet;
import cn.gzhu.wallet.stuff.HLError;
import cn.gzhu.wallet.stuff.HLSubscriber;
import cn.gzhu.wallet.stuff.ScheduleCompat;
import io.github.novacrypto.bip39.MnemonicValidator;
import io.github.novacrypto.bip39.Validation.InvalidChecksumException;
import io.github.novacrypto.bip39.Validation.InvalidWordCountException;
import io.github.novacrypto.bip39.Validation.UnexpectedWhiteSpaceException;
import io.github.novacrypto.bip39.Validation.WordNotFoundException;
import io.github.novacrypto.bip39.wordlists.English;
import io.reactivex.Flowable;

/**
 * @author ASUS
 */
public class LoginActivity extends BaseActivity {

    private EditText mnemonics1;
    private EditText password;
    private EditText rePassword;

    private String mnemonics;
    private String userName;
    private String pwd;
    private String rePwd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        Context mContext = this;

        mnemonics1 = findViewById(R.id.input_mnemonics);
        password = findViewById(R.id.input_password);
        rePassword = findViewById(R.id.input_rePassword);
        Button mButton = findViewById(R.id.button);

        mButton.setOnClickListener((v) -> {

            mnemonics = mnemonics1.getText().toString().trim();
            userName = "unknow";
            KeyStoreUtil.get().generateKey(mContext,userName);
            pwd = KeyStoreUtil.get().encrypt(password.getText().toString(),userName);
            rePwd = KeyStoreUtil.get().encrypt(rePassword.getText().toString(),userName);

            if (TextUtils.isEmpty(mnemonics)) {
                Toast.makeText(mContext, "请输入助记词", Toast.LENGTH_SHORT).show();
            } else if (TextUtils.isEmpty(pwd)) {
                Toast.makeText(mContext, "请输入密码", Toast.LENGTH_SHORT).show();
            } else if (TextUtils.isEmpty(rePwd)) {
                Toast.makeText(mContext, "请重复输入密码", Toast.LENGTH_SHORT).show();
            } else if (!pwd.equals(rePwd)) {
                Toast.makeText(mContext, "前后输入密码不一致", Toast.LENGTH_SHORT).show();
            } else {

                try {
                    MnemonicValidator
                            .ofWordList(English.INSTANCE)
                            .validate(mnemonics);
                    createWallet(mContext,userName,pwd,mnemonics);

                } catch (UnexpectedWhiteSpaceException e) {
                    e.printStackTrace();
                } catch (InvalidWordCountException e) {
                    e.printStackTrace();
                } catch (InvalidChecksumException e) {
                    e.printStackTrace();
                } catch (WordNotFoundException e) {
                    e.printStackTrace();
                    //e.getSuggestion1()
                    //e.getSuggestion2()
                }
            }
        });
    }

    private void createWallet(Context mContext,String userName,String password, String mnemonics) {

        LoadingDialog ld = new LoadingDialog(this);
        ld.setLoadingText("加载中")
                .setSuccessText("加载成功")
                //.setFailedText("加载失败")
                .setInterceptBack(false)
                .setLoadSpeed(LoadingDialog.Speed.valueOf("SPEED_TWO"))
                .closeSuccessAnim()
                .setRepeatCount(2)
                .setShowTime(1000)
                .show();

        Flowable
                .just(password)
                .map(s -> mnemonics)
                .flatMap(s -> InitWalletManager.shared().generateWallet(mContext,KeyStoreUtil.get().decrypt(password,userName),s))
                .compose(ScheduleCompat.apply())
                .subscribe(new HLSubscriber<HLWallet>(mContext,true) {
                    @Override
                    protected void success(HLWallet data) {
                        FileHelper.saveUserInfo(mContext,userName,mnemonics,password);
                        ld.loadSuccess();
                        new Thread() {
                            @Override
                            public void run() {
                                super.run();
                                try {
                                    Thread.sleep(1100);
                                } catch (InterruptedException e) {
                                    e.printStackTrace();
                                }
                                navigateTo(NavigationActivity.class);
                                ActivityCollector.finishOneActivity(MainActivity.class.getName());
                                ld.close();
                                finish();
                            }
                        }.start();
                    }
                    @Override
                    protected void failure(HLError error) {
                        toastMessage("build error,please try again!");
                    }
                });
    }
    public void toastMessage(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
