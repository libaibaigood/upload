package cn.gzhu.wallet.util;


import android.os.Handler;
import android.os.Message;
import android.widget.TextView;

import org.web3j.protocol.Web3j;
import org.web3j.protocol.core.DefaultBlockParameterName;
import org.web3j.protocol.core.JsonRpc2_0Web3j;
import org.web3j.protocol.core.methods.response.EthGetBalance;
import org.web3j.protocol.http.HttpService;
import org.web3j.utils.Convert;

import java.io.IOException;
import java.math.BigDecimal;

import cn.gzhu.wallet.config.HttpServiceUrl;

/**
 * @author ASUS
 */
public class Balance {

    private static final int GET = 1;
    private final static Web3j web3j = new JsonRpc2_0Web3j(new HttpService(HttpServiceUrl.url));


    public String getCurrentBalance(String address) throws IOException {
        EthGetBalance ethGetBlance = web3j.ethGetBalance(address, DefaultBlockParameterName.LATEST).send();
        String balance = Convert.fromWei(new BigDecimal(ethGetBlance.getBalance()), Convert.Unit.ETHER).toPlainString();
        return balance;
    }

    public String roundNoOf(String str, int scale) {
        try {
            // 输入精度小于0则抛出异常
            if (scale < 0) {
                throw new IllegalArgumentException("The scale must be a positive integer or zero");
            }
            // 取得数值
            BigDecimal b = new BigDecimal(str);
            // 取得数值1
            BigDecimal one = new BigDecimal("1");
            // 原始值除以1，保留scale位小数，进行四舍五入
            return b.divide(one, scale, BigDecimal.ROUND_DOWN).toString();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return str;

    }

    public void refreshBalance(Handler handler, String address) {

        final Thread td = new Thread() {
            @Override
            public void run() {
                super.run();
                try {
                    Balance balance = new Balance();
                    String temp = balance.getCurrentBalance(address);
                    Message msg = Message.obtain();
                    msg.what = GET;
                    msg.obj = temp;
                    handler.sendMessage(msg);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        };
        td.start();
    }

}

