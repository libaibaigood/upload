package cn.gzhu.wallet.util;

import com.google.gson.Gson;

/**
 * @author ASUS
 */
public class Singleton {
    public static Gson gson(){
        return GsonHolder.singleton;
    }


    private static class GsonHolder {

        private static final Gson singleton = new Gson();
    }
}
