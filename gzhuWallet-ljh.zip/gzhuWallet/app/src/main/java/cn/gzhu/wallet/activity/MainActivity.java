package cn.gzhu.wallet.activity;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.widget.RelativeLayout;

import java.util.Map;

import cn.gzhu.wallet.FileHelper;
import cn.gzhu.wallet.R;

/**
 * @author 钱包初始界面
 */
public class MainActivity extends BaseActivity {

    private String mnemonics;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        try {
            Map userInfo = FileHelper.getUserInfo(this);
            mnemonics = (String) userInfo.get("mnemonics");
        }catch (Exception e){
            Log.e("tag:", String.valueOf(e));
        }
        if(!TextUtils.isEmpty(mnemonics)){
            navigateTo(CheckActivity.class);
            finish();
        }else {
            RelativeLayout toRegister = findViewById(R.id.to_Register);
            toRegister.setOnClickListener((v)-> navigateTo(RegisterActivity.class));

            RelativeLayout toLogin = findViewById(R.id.to_Login);
            toLogin.setOnClickListener((v)-> navigateTo(LoginActivity.class));

        }
}
}