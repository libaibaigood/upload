package cn.gzhu.wallet;

import android.content.Context;
import android.security.KeyPairGeneratorSpec;
import android.text.TextUtils;
import android.util.Base64;

import java.io.IOException;
import java.math.BigInteger;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.SignatureException;
import java.security.UnrecoverableEntryException;
import java.security.cert.CertificateException;
import java.security.interfaces.RSAPublicKey;
import java.util.Calendar;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.security.auth.x500.X500Principal;

public class KeyStoreUtil {
    private static KeyStoreUtil INSTANCE;
    private static Object LOCK = new Object();
    private KeyStore keyStore;
    private X500Principal x500Principal; //自签署证书
    private static final String CIPHER_TRANSFORMATION = "RSA/ECB/PKCS1Padding";
    public static final String SHA_ALG = "SHA-256"; //sha 算法

    private KeyStoreUtil(){ init();
    }

    private void init() {
        try {
            keyStore = KeyStore.getInstance("AndroidKeyStore");
            keyStore.load(null);

            /**
             *   CN      commonName
             *   O       organizationName
             *   OU      organizationalUnitName
             *   C       countryName
            **/
            x500Principal = new X500Principal("CN=Duke, OU=JavaSoft, O=Sun Microsystems, C=US");
        } catch (KeyStoreException e) {
            e.printStackTrace();
        } catch (CertificateException e) {
            e.printStackTrace();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static KeyStoreUtil get(){
        if (INSTANCE == null){
            synchronized (LOCK){
                if (INSTANCE == null){
                    INSTANCE = new KeyStoreUtil();
                }
            }
        }

        return INSTANCE;
    }

    /**
     * 先判断是否存在该别名
     * */
    public boolean containsAlias(String alias) {
        if (keyStore == null || TextUtils.isEmpty(alias)){
            return false;
        }

        boolean contains = false;
        try{
            contains = keyStore.containsAlias(alias);
        }catch (Exception e){
            e.printStackTrace();
        }
        return contains;
    }

    public void deleteKey(final String alias){
        try{
            keyStore.deleteEntry(alias);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 生成新的密钥
     *
     * @param context
     * @param alias 存储在KeyStore中的别名
     * */
    public KeyPair generateKey(Context context, String alias){
        if (containsAlias(alias)){
            try {
                keyStore.deleteEntry(alias);
            } catch (KeyStoreException e) {
                e.printStackTrace();
            }
        }

        try {
            Calendar endDate = Calendar.getInstance();
            endDate.add(Calendar.YEAR, 10);

            KeyPairGeneratorSpec spec = new KeyPairGeneratorSpec.Builder(context.getApplicationContext())
                    .setAlias(alias)
                    .setSubject(x500Principal)
                    .setSerialNumber(BigInteger.ONE)
                    .setStartDate(Calendar.getInstance().getTime())
                    .setEndDate(endDate.getTime())
                    .build();
            KeyPairGenerator generator = KeyPairGenerator.getInstance("RSA", "AndroidKeyStore");
            generator.initialize(spec);

            return  generator.generateKeyPair();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (NoSuchProviderException e) {
            e.printStackTrace();
        } catch (InvalidAlgorithmParameterException e) {
            e.printStackTrace();
        } catch (NullPointerException e){
            e.printStackTrace();
        }

        return null;
    }

    /**
     * 加密
     *
     * @param input 要加密的数据
     * @param alias KeyStore中的别名
     * */
    public String encrypt(String input, String alias){
        try {
            //取出密钥
            KeyStore.PrivateKeyEntry privateKeyEntry = (KeyStore.PrivateKeyEntry)keyStore.getEntry(alias, null);
            RSAPublicKey publicKey = (RSAPublicKey) privateKeyEntry.getCertificate().getPublicKey();
            byte[] data = input.getBytes();

            Cipher cipher = Cipher.getInstance(CIPHER_TRANSFORMATION);
            cipher.init(Cipher.ENCRYPT_MODE, publicKey);
            return Base64.encodeToString(cipher.doFinal(data),Base64.DEFAULT);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (InvalidKeyException e) {
            e.printStackTrace();
        } catch (UnrecoverableEntryException e) {
            e.printStackTrace();
        } catch (NoSuchPaddingException e) {
            e.printStackTrace();
        } catch (KeyStoreException e) {
            e.printStackTrace();
        } catch (BadPaddingException e) {
            e.printStackTrace();
        } catch (IllegalBlockSizeException e) {
            e.printStackTrace();
        }

        return null;
    }

    /**
     * 解密
     *
     * @param input 要解密的数据
     * @param alias KeyStore中的别名
     * */
    public String decrypt(String input, String alias){
        try {
            //取出密钥
            KeyStore.PrivateKeyEntry privateKeyEntry = (KeyStore.PrivateKeyEntry)keyStore.getEntry(alias, null);
            PrivateKey privateKey = privateKeyEntry.getPrivateKey();
            byte[] data = Base64.decode(input,Base64.DEFAULT);

            Cipher cipher = Cipher.getInstance(CIPHER_TRANSFORMATION);
            cipher.init(Cipher.DECRYPT_MODE, privateKey);
            return new String(cipher.doFinal(data));
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (InvalidKeyException e) {
            e.printStackTrace();
        } catch (UnrecoverableEntryException e) {
            e.printStackTrace();
        } catch (NoSuchPaddingException e) {
            e.printStackTrace();
        } catch (KeyStoreException e) {
            e.printStackTrace();
        } catch (BadPaddingException e) {
            e.printStackTrace();
        } catch (IllegalBlockSizeException e) {
            e.printStackTrace();
        }

        return null;
    }

    //将密钥存储进KeyStore里面
    /**public static void StoreintoKeyStore(KeyPair keyPair,String password) throws Exception {
        byte[] pub = Numeric.toBytesPadded(keyPair.getPublicKey(),64);
        byte[] pri = Numeric.toBytesPadded(keyPair.getPrivateKey(),32);
        AlgorithmParameters parameters = AlgorithmParameters.getInstance("EC");
        parameters.init(new ECGenParameterSpec("prime256v1"));
        ECParameterSpec params = parameters.getParameterSpec(ECParameterSpec.class);
        KeyFactory kf = KeyFactory.getInstance("EC");
        ECPrivateKeySpec priva = new ECPrivateKeySpec(keyPair.getPrivateKey(),params);
        PrivateKey privateKey = kf.generatePrivate(priva);
        PublicKey publickey = kf.generatePublic(new X509EncodedKeySpec(pub));
        //PrivateKey privateKey = getPrivateKeyFromECBigIntAndCurve(new BigInteger("af4d7c4931a4ea740cb6646c8c11687d7097c61e17468421969605c9a1725109",16),"secp256r1");
        //PublicKey publickey = getPublicKeyFromECBigIntAndCurve(new BigInteger(String.valueOf(keyPair.getPublicKey()),16),"secp256r1");
        KeyPair keypairs = new KeyPair(publickey,privateKey);
        X509Certificate selfSignedCertificate = generateSelfSignedCertificate(keyPair);
        //Certificate[] certificateChain = new Certificate[]{selfSignedCertificate};



        KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
        keyStore.load(null,null);
        Certificate[] certChain = new Certificate[1];
        certChain[0] = selfSignedCertificate;
        //SecretKey secretKey = (SecretKey) keyPair.getPrivate();
        //KeyStore.SecretKeyEntry secretKeyEntry = new KeyStore.SecretKeyEntry(secretKey);
        keyStore.setKeyEntry(password, (Key)keyPair.getPrivate(),null,certChain);

    //生成自签名证书
    /**private static X509Certificate generateSelfSignedCertificate(KeyPair keyPair) throws IOException, OperatorCreationException, CertificateException, NoSuchAlgorithmException, SignatureException, NoSuchProviderException, InvalidKeyException {
        Security.addProvider(new BouncyCastleProvider());
        X509V3CertificateGenerator certGen = new X509V3CertificateGenerator();
        certGen.setSerialNumber(BigInteger.valueOf(1));
        certGen.setSubjectDN(new X500Principal("CN=localhost"));
        certGen.setIssuerDN(new X500Principal("CN=localhost"));
        certGen.setPublicKey(keyPair.getPublic());
        certGen.setNotBefore(new Date());
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.YEAR, 100);
        certGen.setNotAfter(calendar.getTime());
        certGen.setSignatureAlgorithm("SHA256WITHECDSA");
        return certGen.generate(keyPair.getPrivate(),"SC");


        Security.addProvider(new BouncyCastleProvider());
        X509V3CertificateGenerator certGen = new X509V3CertificateGenerator();
        X500Principal dnName = new X500Principal("cn=Example_CN");

// add some options
        certGen.setSerialNumber(BigInteger.valueOf(System.currentTimeMillis()));
        certGen.setSubjectDN(new X509Name("dc=Example_Name"));
        certGen.setIssuerDN(dnName); // use the same
// yesterday
        certGen.setNotBefore(new Date(System.currentTimeMillis() - 24 * 60 * 60 * 1000));
// in 2 years
        certGen.setNotAfter(new Date(System.currentTimeMillis() + 2 * 365 * 24 * 60 * 60 * 1000));
        certGen.setPublicKey(keyPair.getPublic());
        certGen.setSignatureAlgorithm("SHA256WITHECDSA");
        certGen.addExtension(X509Extensions.ExtendedKeyUsage, true, new ExtendedKeyUsage(KeyPurposeId.id_kp_timeStamping));

// finally, sign the certificate with the private key of the same KeyPair
        X509Certificate cert = certGen.generate(keyPair.getPrivate(), "SC");





        AlgorithmIdentifier sigAlgId = new DefaultSignatureAlgorithmIdentifierFinder().find("SHA256withECDSA"); // don't use SHA1withRSA. It's not secure anymore.
        AlgorithmIdentifier digAlgId = new DefaultDigestAlgorithmIdentifierFinder().find(sigAlgId);
        AsymmetricKeyParameter keyParam = PrivateKeyFactory.createKey(keyPair.getPrivate().getEncoded());
        SubjectPublicKeyInfo spki = SubjectPublicKeyInfo.getInstance(keyPair.getPublic().getEncoded());
        ContentSigner signer = new BcECContentSignerBuilder(sigAlgId, digAlgId).build(keyParam);
        X500Name issuer = new X500Name("CN=CA, L=Istanbul");
        X500Name subject = new X500Name("CN=gzhuwalletApp, L=Istanbul");
        BigInteger serial = BigInteger.valueOf(1); // Update with unique one if it will be used to identify this certificate
        Calendar notBefore = Calendar.getInstance();
        Calendar notAfter = Calendar.getInstance();
        notAfter.add(Calendar.YEAR, 20); // This certificate is valid for 20 years.

        X509v3CertificateBuilder v3CertGen = new X509v3CertificateBuilder(issuer,
                serial,
                notBefore.getTime(),
                notAfter.getTime(),
                subject,
                spki);
        X509CertificateHolder certificateHolder = v3CertGen.build(signer);

        //return cert;
    }

    public static PublicKey getPublicKeyFromECBigIntAndCurve(BigInteger s, String curveName) {

        ECParameterSpec ecParameterSpec = ECNamedCurveTable.getParameterSpec(curveName);
        byte[] bytes = s.toByteArray();
        BigInteger x = Numeric.toBigInt(Arrays.copyOfRange(bytes, 0, 32));
        BigInteger y = Numeric.toBigInt(Arrays.copyOfRange(bytes, 32, 64));
        ECCurve curve = null;
        ECPoint q = curve.createPoint(x, y);
        ECPublicKeySpec publicKeySpec = new ECPublicKeySpec(q, ecParameterSpec);
        try {
            KeyFactory keyFactory = KeyFactory.getInstance("EC");
            return keyFactory.generatePublic(publicKeySpec);
        } catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static PrivateKey getPrivateKeyFromECBigIntAndCurve(BigInteger s, String curveName) {

        ECParameterSpec ecParameterSpec = ECNamedCurveTable.getParameterSpec(curveName);

        ECPrivateKeySpec privateKeySpec = new ECPrivateKeySpec(s, ecParameterSpec);
        try {
            KeyFactory keyFactory = KeyFactory.getInstance("EC");
            return keyFactory.generatePrivate(privateKeySpec);
        } catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    /**public static KeyPair decodeKeyPair(ECKeyPair ecKeyPair) {
        byte[] bytes = Numeric.toBytesPadded(ecKeyPair.getPublicKey(), 64);
        BigInteger x = Numeric.toBigInt(Arrays.copyOfRange(bytes, 0, 32));
        BigInteger y = Numeric.toBigInt(Arrays.copyOfRange(bytes, 32, 64));
        ECCurve curve = null;
        ECPoint q = curve.createPoint(x, y);
        BCECPublicKey publicKey = new BCECPublicKey("EC", new ECPublicKeyParameters(q, dp), BouncyCastleProvider.CONFIGURATION);
        BCECPrivateKey privateKey = new BCECPrivateKey("EC", new ECPrivateKeyParameters(ecKeyPair.getPrivateKey(), dp), publicKey, p, BouncyCastleProvider.CONFIGURATION);
        return new KeyPair(publicKey, privateKey);
    }

    private PublicKey convertPublicKey(byte[] publicKey) throws Exception{
        PublicKey pub = null;

        X509EncodedKeySpec pubSpec = new X509EncodedKeySpec(publicKey);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        pub = (RSAPublicKey) keyFactory.generatePublic(pubSpec);

        return pub;
    }

    private PrivateKey convertPrivatekey(byte[] privateKey) throws Exception{
        PrivateKey pri = null;

        X509EncodedKeySpec priSpec = new X509EncodedKeySpec(privateKey);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        pri = (RSAPrivateKey) keyFactory.generatePublic(priSpec);

        return pri;
    }**/

    /**
     * 对数据进行签名
     *
     * @param data
     * @param alias
     * */
    public byte[] sign(byte[] data, String alias){
        try{
            //取出密钥
            KeyStore.PrivateKeyEntry privateKeyEntry = (KeyStore.PrivateKeyEntry)keyStore.getEntry(alias, null);
            Signature s = Signature.getInstance("SHA256withRSA");
            s.initSign(privateKeyEntry.getPrivateKey());
            s.update(data);
            return s.sign();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (KeyStoreException e) {
            e.printStackTrace();
        } catch (UnrecoverableEntryException e) {
            e.printStackTrace();
        } catch (SignatureException e) {
            e.printStackTrace();
        } catch (InvalidKeyException e) {
            e.printStackTrace();
        }

        return null;
    }

    /**
     * 验证数据签名
     *
     * @param data 原始数据
     * @param signatureData 签署的数据
     * @param alias
     * */
    public boolean verify (byte[] data, byte[] signatureData, String alias){
        try{
            //取出密钥
            KeyStore.PrivateKeyEntry privateKeyEntry = (KeyStore.PrivateKeyEntry)keyStore.getEntry(alias, null);

            Signature s = Signature.getInstance("SHA256withRSA");
            s.initVerify(privateKeyEntry.getCertificate());
            s.update(data);
            return s.verify(signatureData);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (InvalidKeyException e) {
            e.printStackTrace();
        } catch (SignatureException e) {
            e.printStackTrace();
        } catch (UnrecoverableEntryException e) {
            e.printStackTrace();
        } catch (KeyStoreException e) {
            e.printStackTrace();
        }
        return false;
    }
}
