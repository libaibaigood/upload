package cn.gzhu.wallet.activity;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.view.KeyEvent;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;

import cn.gzhu.wallet.R;

public class TransferInfoActivity extends AppCompatActivity {

    private WebView mWebview;
    private static int account=1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transfer_info);

        Intent intent = getIntent();
        String url = intent.getStringExtra("url");

        mWebview= (WebView) findViewById(R.id.name_info);
        //使用JAvascript语言
        mWebview.getSettings().setJavaScriptEnabled(true);
        //使用app打开网页
        mWebview.setWebViewClient(new MyWebViewClient());
        //设置网页组件功能
        mWebview.setWebChromeClient(new MyWebChromeClient());
//        mWebview.loadUrl("http://psy.yangtzeu.edu.cn/psym/SelfHelp/ArticleList.aspx");
        //设置链接
        mWebview.loadUrl(url);
    }

    class MyWebViewClient extends WebViewClient {
        @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            view.loadUrl(request.getUrl().toString());
            return true;
        }
        //在进入页面前的操作，这里为弹出alert框口。
        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            super.onPageStarted(view, url, favicon);

            if(account++ == 1){
                mWebview.loadUrl("javascript:alert('友情提示:账号为学号,密码为出生年月日,eg:账号：201607881 密码：19980101')");
            }}
        //页面结束后发生的操作
        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
        }
    }
    class MyWebChromeClient extends WebChromeClient {
        @Override
        public void onProgressChanged(WebView view, int newProgress) {
            super.onProgressChanged(view, newProgress);
        }
        //更改页面标题
        @Override
        public void onReceivedTitle(WebView view, String title) {
            super.onReceivedTitle(view, title);
            setTitle(title);
        }
    }
    //设置后退键为返回上一步的操作
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if(keyCode== KeyEvent.KEYCODE_BACK &&mWebview.canGoBack()){
            mWebview.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
}
