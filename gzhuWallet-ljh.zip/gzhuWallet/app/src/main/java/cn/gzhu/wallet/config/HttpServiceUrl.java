package cn.gzhu.wallet.config;

/**
 * @author ASUS
 */
public interface HttpServiceUrl {
    String url = "https://ropsten.infura.io/v3/9aa3d95b3bc440fa88ea12eaa4456161";
}
