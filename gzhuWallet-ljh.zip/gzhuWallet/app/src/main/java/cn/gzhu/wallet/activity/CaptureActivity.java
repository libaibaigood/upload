package cn.gzhu.wallet.activity;

public class CaptureActivity extends com.journeyapps.barcodescanner.CaptureActivity {

}