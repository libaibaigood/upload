package cn.gzhu.wallet.ui.dashboard;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import cn.gzhu.wallet.FileHelper;
import cn.gzhu.wallet.activity.MainActivity;
import cn.gzhu.wallet.OkManager;
import cn.gzhu.wallet.R;
import cn.gzhu.wallet.databinding.FragmentDashboardBinding;
import cn.gzhu.wallet.manager.WalletManager;

/**
 * @author ASUS
 */
public class DashboardFragment extends Fragment {

    private FragmentDashboardBinding binding;
    private Context mContext;

    private Button btnGet;
    private TextView resultText;
    private OkManager manager;


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        DashboardViewModel dashboardViewModel =
                new ViewModelProvider(this).get(DashboardViewModel.class);


        binding = FragmentDashboardBinding.inflate(inflater, container, false);
        View root = binding.getRoot();
        mContext = root.getContext();

        manager = OkManager.getInstance();
        btnGet = root.findViewById(R.id.getInternet);
        resultText = root.findViewById(R.id.result);
        btnGet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                manager.asyncJsonStringByURL("https://www.baidu.com/", new OkManager.Fun1() {
//                    @Override
//                    public void onResponse(String result) {
//                        Log.i("Tag", result);   //获取JSON字符串
//                        resultText.setText(result);
//                    }
//                });

                Map<String, String> map = new HashMap<String, String>();
                map.put("username", "123");
                map.put("password", "123");
                try{
                    manager.sendComplexForm(" https://www.baidu.com/", map, new OkManager.Fun4() {
                        @Override
                        public void onResponse(JSONObject jsonObject) {
                            Log.i("Tag", jsonObject.toString());
                            resultText.setText(jsonObject.toString());
                            Log.e("111","1111");
                        }
                    });
                }catch (Exception e){

                }
            }
        });


        return root;
    }



    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}