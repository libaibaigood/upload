package cn.gzhu.wallet.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import org.greenrobot.eventbus.EventBus;

import cn.gzhu.wallet.ActivityCollector;

/**
 * @author ASUS
 */
public class BaseActivity extends AppCompatActivity {
    private Context mContext;
    public void toastMsg(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mContext = this;

        ActivityCollector.addActivity(this);

        // 事件消息订阅
        if (isRegisterEvent() && !EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().register(this);
        }
    }

    public void navigateTo(Class cls) {
        Intent in = new Intent(mContext, cls);
        startActivity(in);
    }

    protected boolean isRegisterEvent() {
        return false;
    }
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
        //从活动管理器删除当前Activity
        ActivityCollector.removeActivity(this);

    }

}