package cn.gzhu.wallet.activity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.scwang.smart.refresh.footer.ClassicsFooter;
import com.scwang.smart.refresh.header.ClassicsHeader;
import com.scwang.smart.refresh.layout.api.RefreshLayout;
import com.scwang.smart.refresh.layout.listener.OnLoadMoreListener;
import com.scwang.smart.refresh.layout.listener.OnRefreshListener;

import java.util.LinkedList;
import java.util.List;

import cn.gzhu.wallet.Data;
import cn.gzhu.wallet.DetailList;
import cn.gzhu.wallet.R;
import cn.gzhu.wallet.util.Balance;

/**
 * @author ASUS
 */
public class DetailActivity extends BaseActivity {

    private ListView list_one;
    private cn.gzhu.wallet.DetailList DetailList = null;
    private List<Data> mData = null;
    private Context mContext = null;
    private TextView back;
    Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        context = this;

        RefreshLayout refreshLayout = (RefreshLayout)findViewById(R.id.refreshLayout_detail);
        refreshLayout.setRefreshHeader(new ClassicsHeader(context));
        refreshLayout.setRefreshFooter(new ClassicsFooter(context));
        refreshLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshlayout) {
// ToDo 刷新列表
                refreshlayout.finishRefresh(2000/*,false*/);//传入false表示刷新失败
            }
        });
        refreshLayout.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshlayout) {
                refreshlayout.finishLoadMore(2000/*,false*/);//传入false表示加载失败
            }
        });


        back = findViewById(R.id.btn_back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                navigateTo(NavigationActivity.class);
                finish();
            }
        });
        mContext = DetailActivity.this;
        bindViews();
        mData = new LinkedList<Data>();

        DetailList = new DetailList((LinkedList<Data>) mData,mContext);
        list_one.setAdapter(DetailList);


        for (int i =0;i<20;i++){
            Data data = new Data("111","222","333");
            DetailList.add(data);
        }
    }

    private void bindViews(){
        list_one = (ListView) findViewById(R.id.list_one);
    }


}