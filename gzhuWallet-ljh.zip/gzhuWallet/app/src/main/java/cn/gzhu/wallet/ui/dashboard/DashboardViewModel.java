package cn.gzhu.wallet.ui.dashboard;

import androidx.lifecycle.ViewModel;

/**
 * @author ASUS
 */
public class DashboardViewModel extends ViewModel {


}