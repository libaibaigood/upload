package cn.gzhu.wallet.config;

public interface Constant {
    String PREFIX_16 = "0x";
}
