package cn.gzhu.wallet.manager;

import android.content.Context;
import android.os.Handler;
import android.os.Message;

import androidx.annotation.NonNull;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.xiasuhuei321.loadingdialog.view.LoadingDialog;

import org.greenrobot.eventbus.EventBus;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ExecutionException;

import cn.gzhu.wallet.Transaction;
import cn.gzhu.wallet.config.Tag;
import cn.gzhu.wallet.model.HLWallet;
import cn.gzhu.wallet.model.SwitchWalletEvent;
import cn.gzhu.wallet.model.WalletStore;
import cn.gzhu.wallet.util.ACache;
import cn.gzhu.wallet.util.Singleton;

/**
 * @author ASUS
 */
public class WalletManager {
    private static final ObjectMapper objectMapper = new ObjectMapper();
    private final HashMap<String, HLWallet> mHLWalletHashMap = new LinkedHashMap<>();
    private HLWallet mCurrentWallet;

    public void saveWallet(Context context, HLWallet wallet) {
        updateWallet(context, wallet);
        switchCurrentWallet(context, wallet);
    }

    public void updateWallet(Context context, HLWallet wallet) {
        mHLWalletHashMap.put(wallet.getAddress(), wallet);
        updateWallets(context);
    }

    public void updateWallets(Context context) {
        WalletStore walletStore = new WalletStore();
        walletStore.wallets = mHLWalletHashMap;
        String json = Singleton.gson().toJson(walletStore, WalletStore.class);
        ACache.get(context).put(Tag.WALLETS, json);
    }

    public void switchCurrentWallet(Context context, @NonNull HLWallet item) {
        if (mCurrentWallet != null) {
            mCurrentWallet.isCurrent = false;
        }
        mCurrentWallet = item;
        item.isCurrent = true;
        ACache.get(context).put(Tag.CURRENT_ADDRESS, item.getAddress());
        EventBus.getDefault().post(new SwitchWalletEvent());
    }

    public HLWallet getCurrentWallet(Context context) {
        if (mCurrentWallet == null) {
            //if not current wallet, try to load wallet files
            loadWallets(context);
            //no wallets, return null
            if (mHLWalletHashMap.isEmpty()) {
                return null;
            } else {
                //if get wallets, try to get user prefer wallet
                String address = ACache.get(context).getAsString(Tag.CURRENT_ADDRESS);
                if (address.length() > 0) {
                    //get user prefer wallet
                    switchCurrentWallet(context, Objects.requireNonNull(mHLWalletHashMap.get(address)));
                } else {
                    // if not prefer, get the first wallet
                    Iterator<String> iterator = mHLWalletHashMap.keySet().iterator();
                    switchCurrentWallet(context, Objects.requireNonNull(mHLWalletHashMap.get(iterator.next())));

                }
            }
        }
        return mCurrentWallet;
    }

    public List<HLWallet> getWallets() {
        return new ArrayList<>(mHLWalletHashMap.values());
    }

    public void loadWallets(Context context) {
        try {
            String jsonString = ACache.get(context).getAsString(Tag.WALLETS);
            if (jsonString != null) {
                WalletStore store = objectMapper.readValue(jsonString, WalletStore.class);
                if (store != null) {
                    mHLWalletHashMap.clear();
                    mHLWalletHashMap.putAll(store.wallets);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public boolean isWalletExist(String address) {
        Set<String> strings = mHLWalletHashMap.keySet();
        for (String s : strings) {
            if (s.equalsIgnoreCase(address)) {
                return true;
            }
        }
        return false;
    }

    public void transaction(LoadingDialog ld,Handler handler, String from, String amount, String to, String privatekey) {

        ld.setLoadingText("发送中")
                .setSuccessText("交易成功")
                .setFailedText("加载失败")
                .setInterceptBack(false)
                .setLoadSpeed(LoadingDialog.Speed.valueOf("SPEED_TWO"))
                .closeSuccessAnim()
                .setRepeatCount(2)
                .setShowTime(1000)
                .show();
        final Thread td = new Thread() {
            @Override
            public void run() {
                super.run();
                try {
                    String result = Transaction.signETHTransaction(from, amount, "0x21197647b87F385c7284de7e31d1F2bba39a5bAb", privatekey);
                    Message msg = Message.obtain();
                    msg.what = 1;
                    msg.obj = result;
                    handler.sendMessage(msg);
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (ExecutionException e) {
                    e.printStackTrace();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        };
        td.start();

    }

    // ---------------- singleton stuff --------------------------
    public static WalletManager shared() {
        return WalletManager.Holder.singleton;
    }

    private WalletManager() {

    }

    private static class Holder {

        private static final WalletManager singleton = new WalletManager();

    }
}
