package cn.gzhu.wallet;

import org.web3j.crypto.Credentials;
import org.web3j.crypto.RawTransaction;
import org.web3j.crypto.TransactionEncoder;
import org.web3j.protocol.Web3j;
import org.web3j.protocol.core.DefaultBlockParameterName;
import org.web3j.protocol.core.JsonRpc2_0Web3j;
import org.web3j.protocol.http.HttpService;
import org.web3j.utils.Convert;
import org.web3j.utils.Numeric;

import java.io.IOException;
import java.math.BigInteger;
import java.util.concurrent.ExecutionException;

import cn.gzhu.wallet.config.HttpServiceUrl;

public class Transaction {

    private final static Web3j web3j = new JsonRpc2_0Web3j(new HttpService(HttpServiceUrl.url));

    public static String signETHTransaction(String from,String amount,String to,String privateKey) throws IOException, ExecutionException, InterruptedException {

//        //发送方地址
//        String from = "0xd4cad7bea2845a5c98d41cd5b696cf2ed924a360";
//        //转账数量
//        String amount = "0.5";
//        //接收者地址
//        String to = "0x21197647b87F385c7284de7e31d1F2bba39a5bAb";
//        //发送方私钥
//        String privateKey = "0xab430b39fae59b04e337683f3f6fce686da274d2ffcc63b52e209c0d400a43fa";
        //查询地址交易编号
        BigInteger nonce = web3j.ethGetTransactionCount(from, DefaultBlockParameterName.PENDING).send().getTransactionCount();
        //支付的矿工费
        BigInteger gasPrice = web3j.ethGasPrice().send().getGasPrice();
        BigInteger gasLimit = new BigInteger("210000");

        BigInteger amountWei = Convert.toWei(amount, Convert.Unit.ETHER).toBigInteger();
        //签名交易
        RawTransaction rawTransaction = RawTransaction.createTransaction(nonce, gasPrice, gasLimit, to, amountWei, "");
        Credentials credentials = Credentials.create(privateKey);
        byte[] signMessage = TransactionEncoder.signMessage(rawTransaction, credentials);
        //byte[] signMessage = KeyStoreUtil.get().sign(rawTransaction.toString().getBytes(),password);
        //广播交易
        String hash = web3j.ethSendRawTransaction(Numeric.toHexString(signMessage)).sendAsync().get().getTransactionHash();
        System.out.println("hash:" + hash);
        return hash;
    }

}
