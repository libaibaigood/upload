package cn.gzhu.wallet.ui.home;
import androidx.lifecycle.ViewModel;

/**
 * @author ASUS
 */
public class HomeViewModel extends ViewModel {

}