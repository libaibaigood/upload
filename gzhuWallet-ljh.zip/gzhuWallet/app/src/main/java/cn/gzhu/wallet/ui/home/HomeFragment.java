package cn.gzhu.wallet.ui.home;

import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.google.zxing.integration.android.IntentIntegrator;
import com.scwang.smart.refresh.footer.ClassicsFooter;
import com.scwang.smart.refresh.header.ClassicsHeader;
import com.scwang.smart.refresh.layout.api.RefreshLayout;
import com.scwang.smart.refresh.layout.listener.OnLoadMoreListener;
import com.scwang.smart.refresh.layout.listener.OnRefreshListener;

import java.util.LinkedList;
import java.util.List;

import cn.gzhu.wallet.Data;
import cn.gzhu.wallet.DetailList;
import cn.gzhu.wallet.FileHelper;
import cn.gzhu.wallet.QrCode;
import cn.gzhu.wallet.R;
import cn.gzhu.wallet.activity.CaptureActivity;
import cn.gzhu.wallet.activity.DetailActivity;
import cn.gzhu.wallet.activity.MainActivity;
import cn.gzhu.wallet.activity.PaymentActivity;
import cn.gzhu.wallet.activity.TransferActivity;
import cn.gzhu.wallet.databinding.FragmentHomeBinding;
import cn.gzhu.wallet.manager.WalletManager;
import cn.gzhu.wallet.model.HLWallet;
import cn.gzhu.wallet.util.Balance;

/**
 * @author 主页
 */
public class HomeFragment extends Fragment {

    private Button toDetail;
    private Button toTransfer;
    private Button toPayment;
    private Button toRequest;
    private Button copy;
    private Button share;
    private TextView addressText;
    private TextView addressTextShow_1;
    private TextView balanceShow;
    private TextView sideBarBalance;
    private ImageView QRCodeAddress;
    private ListView list_one;
    private cn.gzhu.wallet.DetailList DetailList = null;
    private FragmentHomeBinding binding;
    private Context context;
    private List<Data> mData = null;

    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case 1:
                    String bal = new Balance().roundNoOf((String) msg.obj, 2);
                    balanceShow.setText(bal);
                    sideBarBalance.setText(bal);
                    break;
            }
        }
    };

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        HomeViewModel homeViewModel =
                new ViewModelProvider(this).get(HomeViewModel.class);

        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();
        context = root.getContext();
        balanceShow = root.findViewById(R.id.balance);
        sideBarBalance = root.findViewById(R.id.sideBar_balance);
        addressTextShow_1 = root.findViewById(R.id.address_one);
        balanceShow.setText("ETH:  0.00");
        HLWallet hlWallet;
        hlWallet = WalletManager.shared().getCurrentWallet(context);
        String address = hlWallet.getAddress();
        String add = address.substring(0, 16) + "...." + address.substring(address.length() - 10, address.length());
        new Balance().refreshBalance(handler, address);

        addressTextShow_1.setText(add);
        addressText = root.findViewById(R.id.address);
        addressText.setText(address);

        toDetail = root.findViewById(R.id.to_detail);
        toTransfer = root.findViewById(R.id.to_transfer);
        toPayment = root.findViewById(R.id.to_payment);
        toRequest = root.findViewById(R.id.to_request);
        copy = root.findViewById(R.id.bt_copy);
        share = root.findViewById(R.id.bt_share);
        list_one = root.findViewById(R.id.list_one);

        copy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ClipboardManager cbm = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
                cbm.setText(address);
                Toast.makeText(context, "复制成功", Toast.LENGTH_LONG).show();
            }
        });

        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent sendIntent = new Intent();
                sendIntent.setAction(Intent.ACTION_SEND);
                sendIntent.putExtra(Intent.EXTRA_TEXT, address);
                sendIntent.setType("text/plain");
                context.startActivity(sendIntent);

            }
        });

        Typeface font = Typeface.createFromAsset(context.getAssets(), "iconfont.ttf");
        toTransfer.setTypeface(font);

        toPayment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), PaymentActivity.class);
                startActivity(intent);
            }
        });
        toDetail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), DetailActivity.class);
                startActivity(intent);
            }
        });
        toTransfer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), TransferActivity.class);
                startActivity(intent);
            }
        });

        mData = new LinkedList<Data>();
        DetailList = new DetailList((LinkedList<Data>) mData, context);
        list_one.setAdapter(DetailList);
        for (int i = 0; i < 5; i++) {
            Data data = new Data("111", "222", "333");
            DetailList.add(data);
        }

        RefreshLayout refreshLayout = (RefreshLayout) root.findViewById(R.id.refreshLayout);
        refreshLayout.setRefreshHeader(new ClassicsHeader(context));
        refreshLayout.setRefreshFooter(new ClassicsFooter(context));
        refreshLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshlayout) {
                new Balance().refreshBalance(handler, address);
                refreshlayout.finishRefresh(2000/*,false*/);//传入false表示刷新失败
            }
        });
        refreshLayout.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshlayout) {
                refreshlayout.finishLoadMore(2000/*,false*/);//传入false表示加载失败
            }
        });

        QRCodeAddress = root.findViewById(R.id.QRCode_address);
        QrCode qrcode = new QrCode();
        Bitmap bitmap = qrcode.qrcode(address);
        QRCodeAddress.setImageBitmap(bitmap);


        return root;
    }


    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        menu.add(1, 1, 1, "扫描二维码");
        menu.add(1, 2, 2, "退出登录");
        menu.add(1, 3, 3, ".......");
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();
        switch (id) {
            case 1:
                if (Build.VERSION.SDK_INT > 22) {
                    if (ContextCompat.checkSelfPermission(getActivity(),
                            android.Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                        //先判断有没有权限 ，没有就在这里进行权限的申请
                        ActivityCompat.requestPermissions(getActivity(),
                                new String[]{android.Manifest.permission.CAMERA}, 1);
                    } else {
                        IntentIntegrator intentIntegrator = new IntentIntegrator(getActivity());
                        intentIntegrator.setPrompt("请扫描二维码！");
                        intentIntegrator.setBeepEnabled(true);
                        intentIntegrator.setOrientationLocked(true);
                        intentIntegrator.setCaptureActivity(CaptureActivity.class);
                        intentIntegrator.initiateScan();
                    }
                }

                break;
            case 2:
                FileHelper.saveUserInfo(context,"","","");
                Intent intent = new Intent(getActivity(), MainActivity.class);
                startActivity(intent);
                getActivity().finish();
                break;
            case 3:

                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
        // 这是关键的一句
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}

