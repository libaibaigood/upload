package cn.gzhu.wallet.config;

/**
 * @author ASUS
 */
public interface Tag {
    String WALLETS = "WALLETS";

    String CURRENT_ADDRESS = "CURRENT_ADDRESS";

    String DATA = "DATA";

    String INDEX = "INDEX";
}
