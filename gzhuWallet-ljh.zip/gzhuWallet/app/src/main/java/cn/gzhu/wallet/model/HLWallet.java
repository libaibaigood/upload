package cn.gzhu.wallet.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

import org.web3j.crypto.WalletFile;

import cn.gzhu.wallet.config.Constant;

/**
 * @author ASUS
 */
public class HLWallet {

    public WalletFile walletFile;

    @JsonIgnore
    public boolean isCurrent = false;

    public HLWallet() {

    }

    public HLWallet(WalletFile walletFile) {
        this.walletFile = walletFile;
    }

    public String getAddress(){
        return Constant.PREFIX_16 + this.walletFile.getAddress();
    }


}
