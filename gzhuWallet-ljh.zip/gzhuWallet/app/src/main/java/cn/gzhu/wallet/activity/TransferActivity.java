package cn.gzhu.wallet.activity;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.xiasuhuei321.loadingdialog.view.LoadingDialog;

import org.web3j.crypto.CipherException;
import org.web3j.crypto.ECKeyPair;
import org.web3j.crypto.Wallet;

import java.math.BigInteger;
import java.util.Map;

import cn.gzhu.wallet.FileHelper;
import cn.gzhu.wallet.KeyStoreUtil;
import cn.gzhu.wallet.R;
import cn.gzhu.wallet.manager.WalletManager;
import cn.gzhu.wallet.model.HLWallet;
import cn.gzhu.wallet.util.Balance;
import cn.gzhu.wallet.util.BytesUtil;

/**
 * @author ASUS
 */
public class TransferActivity extends BaseActivity {

    private EditText btcNum;
    private EditText inputPassword;
    private TextView balanceShow;
    private EditText addressTo;
    private Button btnSend;
    LoadingDialog ld;
    Context context;
    private android.os.Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case 1:
                    balanceShow.setText(new Balance().roundNoOf((String) msg.obj, 2));
                    break;
            }
        }
    };

    private Handler handler1 = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case 1:
                    ld.setSuccessText("交易成功,hash:"+(String) msg.obj);
                    ld.loadSuccess();
                    new Thread() {
                        @Override
                        public void run() {
                            super.run();
                            try {
                                Thread.sleep(1100);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                            ld.close();
                        }
                    }.start();
                    break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transfer);

        context = this;
        balanceShow = findViewById(R.id.balance_show);
        btcNum = findViewById(R.id.btc_num);
        addressTo = findViewById(R.id.address_to);
        btnSend = findViewById(R.id.bt_send);
        inputPassword = findViewById(R.id.pwd);

        HLWallet hlWallet;
        hlWallet = WalletManager.shared().getCurrentWallet(context);
        String address = hlWallet.getAddress();

        Balance getBalance = new Balance();
        getBalance.refreshBalance(handler, address);
        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Map userInfo = FileHelper.getUserInfo(context);
                String password = (String) userInfo.get("password");
                if (inputPassword.getText().toString().trim().equals(KeyStoreUtil.get().decrypt(password,(String) userInfo.get("userName")))) {
                    String amount = btcNum.getText().toString().trim();
                    String addressPayFor = addressTo.getText().toString().trim();
                    ECKeyPair pk = null;
                    try {
                        pk = Wallet.decrypt(KeyStoreUtil.get().decrypt(password,(String) userInfo.get("userName")), hlWallet.walletFile);
                    } catch (CipherException e) {
                        e.printStackTrace();
                    }

                    ld = new LoadingDialog(context);
                    WalletManager.shared().transaction(ld,handler1, address, amount, addressPayFor, BytesUtil.bytes2Hex(toByteArray(pk.getPrivateKey())));
                    System.out.println(amount + "||||||||" + addressPayFor);
                } else {
                    toastMsg("密码错误");
                }
            }
        });

    }

    public static byte[] toByteArray(BigInteger bi) {
        byte[] array = bi.toByteArray();
        // 这种情况是转换的array超过25位
        if (array[0] == 0) {
            byte[] tmp = new byte[array.length - 1];
            System.arraycopy(array, 1, tmp, 0, tmp.length);
            array = tmp;
        }
        // 假如转换的byte数组少于24位，则在前面补齐0
        if (array.length < 24) {
            byte[] tmp = new byte[24];
            System.arraycopy(array, 0, tmp, 24 - array.length, array.length);
            array = tmp;
        }
        return array;
    }
}