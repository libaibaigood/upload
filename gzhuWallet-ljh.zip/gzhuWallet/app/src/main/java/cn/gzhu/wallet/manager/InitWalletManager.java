package cn.gzhu.wallet.manager;

import static cn.gzhu.wallet.util.BytesUtil.bytes2Hex;
import static cn.gzhu.wallet.util.BytesUtil.hex2Bytes;

import android.content.Context;

import com.fasterxml.jackson.databind.ObjectMapper;

import org.spongycastle.util.encoders.Hex;
import org.web3j.crypto.ECKeyPair;
import org.web3j.crypto.Wallet;
import org.web3j.crypto.WalletFile;

import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.util.Arrays;

import cn.gzhu.wallet.config.Constant;
import cn.gzhu.wallet.model.HLWallet;
import cn.gzhu.wallet.stuff.HLError;
import cn.gzhu.wallet.stuff.LWallet;
import cn.gzhu.wallet.stuff.ReplyCode;
import io.github.novacrypto.bip32.ExtendedPrivateKey;
import io.github.novacrypto.bip32.networks.Bitcoin;
import io.github.novacrypto.bip39.MnemonicGenerator;
import io.github.novacrypto.bip39.SeedCalculator;
import io.github.novacrypto.bip39.Words;
import io.github.novacrypto.bip39.wordlists.English;
import io.github.novacrypto.bip44.AddressIndex;
import io.github.novacrypto.bip44.BIP44;
import io.reactivex.Flowable;
/**
 * @author ASUS
 */
public class InitWalletManager {

    /**
     * generate a random group of mnemonics
     * 生成一组随机的助记词
     */
    public String generateMnemonics() {
        StringBuilder sb = new StringBuilder();
        byte[] entropy = new byte[Words.TWELVE.byteLength()];
        new SecureRandom().nextBytes(entropy);
        new MnemonicGenerator(English.INSTANCE)
                .createMnemonic(entropy, sb::append);
        return sb.toString();
    }

    /**
     * @param context   app context 上下文
     * @param password  the wallet password(not the bip39 password) 钱包密码(而不是BIP39的密码)
     * @param mnemonics 助记词
     * @return wallet 钱包
     */
    public Flowable<HLWallet> generateWallet(Context context,
                                             String password,
                                             String mnemonics) {
        Flowable<String> flowable = Flowable.just(mnemonics);
        return flowable
                .map(s -> {
                    WalletFile walletFile = Wallet.createLight(password, generateKeyPair(s));
                    HLWallet hlWallet = new HLWallet(walletFile);
                    WalletManager.shared().saveWallet(context, hlWallet);
                    return hlWallet;
                });
    }


    public Flowable<HLWallet> importMnemonic(Context context,
                                             String password,
                                             String mnemonics) {
        Flowable<String> flowable = Flowable.just(mnemonics);

        return flowable
                .flatMap(s -> {
                    ECKeyPair keyPair = generateKeyPair(s);
                    WalletFile walletFile = Wallet.createLight(password, keyPair);
                    HLWallet hlWallet = new HLWallet(walletFile);
                    if (WalletManager.shared().isWalletExist(hlWallet.getAddress())) {
                        return Flowable.error(new HLError(ReplyCode.walletExisted, new Throwable("Wallet existed!")));
                    }
                    WalletManager.shared().saveWallet(context, hlWallet);
                    return Flowable.just(hlWallet);
                });
    }



    public String mnemonicToSeed(String mnemonic) {
        /**
         *
         Most wallet software defaults to empty passphrase
         */
        byte[] seed = new SeedCalculator().calculateSeed(
                mnemonic, "");
        return bytes2Hex(seed);
    }

    /**public ECKeyPairs(byte[] privateKey) {
        privateKey = Arrays.copyOf(privateKey, privateKey.length);
        org.bouncycastle.jce.interfaces.ECPrivateKey ecPrivateKey;
        try {
            ECDomainParameters domain = ECKeyPairGenerator.getDomain(((privateKey.length - 1) * 8));
            ECPrivateKeySpec privateKeySpec = new ECPrivateKeySpec(
                    new BigInteger(1, privateKey),
                    new ECParameterSpec(domain.getCurve(), domain.getG(), domain.getN(), domain.getH())
            );
            ecPrivateKey = (ECPrivateKey) KeyFactory.getInstance("EC", "BC").generatePrivate(privateKeySpec);
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage());
        }
        try {
            ECDomainParameters domain = ECKeyPairGenerator.getDomain((privateKey.length - 1) * 8);
            ECPublicKeySpec publicKeySpec = new ECPublicKeySpec(
                    domain.getG().multiply(ecPrivateKey.getD()),
                    new ECParameterSpec(domain.getCurve(), domain.getG(), domain.getN(), domain.getH())
            );
            this.publicKey = new ECPublicKey(
                    ((org.bouncycastle.jce.interfaces.ECPublicKey) KeyFactory.getInstance("EC", "BC")
                            .generatePublic(publicKeySpec)).getQ().getEncoded(true));
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage());
        }
    }

    public String getProviderName() {
        return "SunEC";
    }

     * Convert a byte array to an EC private key by decoding the D number
     * parameter.
     *
     * @param keyBytes Bytes to be converted to the EC private key.
     * @return An instance of EC private key decoded from the input bytes.
     * @throws InvalidKeySpecException The provided key bytes are not a valid EC
     *                                 private key.
     * @throws CryptoProviderException When crypto provider is incorrectly initialized.
     */
    /**protected KeyPair generatekeypair(byte[] keyBytes,String password) throws Exception {
        //try {

        Security.addProvider(new BouncyCastleProvider());
        KeyFactory kf = KeyFactory.getInstance("EC","SC");
        ECNamedCurveParameterSpec spec = ECNamedCurveTable.getParameterSpec("secp256k1");
        ECPrivateKeySpec ecPrivateKeySpec = new ECPrivateKeySpec(Numeric.toBigInt(keyBytes),spec);
        PrivateKey privateKey = kf.generatePrivate(ecPrivateKeySpec);
        ECPoint point = spec.getG().multiply(Numeric.toBigInt(keyBytes));
        ECPublicKeySpec ecPublicKeySpec = new ECPublicKeySpec(point,spec);
        PublicKey publicKey = kf.generatePublic(ecPublicKeySpec);
        KeyPair keyPair = new KeyPair(publicKey,privateKey);
        KeyStoreUtil.StoreintoKeyStore(keyPair,password);
        KeyFactory kf = null;
        try {
            kf = KeyFactory.getInstance("ECDH", getProviderName());
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (NoSuchProviderException e) {
            e.printStackTrace();
        }
        ECNamedCurveParameterSpec ecSpec = ECNamedCurveTable.getParameterSpec("secp256r1");
            if (ecSpec == null) { // can happen with incorrectly initialized crypto provider

            }
            ECPoint point = ecSpec.getCurve().decodePoint(keyBytes);
            ECPublicKeySpec pubSpec = new ECPublicKeySpec(point, ecSpec);

            KeyFactory kf = KeyFactory.getInstance("EC");
            BigInteger keyInteger = new BigInteger(keyBytes);
            X9ECParameters CURVE_PARAMS = CustomNamedCurves.getByName("secp256k1");
            ECParameterSpec ecSpec = new ECParameterSpec(CURVE_PARAMS.getCurve(),CURVE_PARAMS.getG(),CURVE_PARAMS.getN(),CURVE_PARAMS.getH(),CURVE_PARAMS.getSeed());
            ECPrivateKeySpec priSpec = new ECPrivateKeySpec(keyInteger, ecSpec);
            if (keyInteger.bitLength() > CURVE_PARAMS.getN().bitLength()) {
                keyInteger = keyInteger.mod(CURVE_PARAMS.getN());
            }
            ECPoint point = new FixedPointCombMultiplier().multiply(CURVE_PARAMS.getG(),keyInteger);
            ECPublicKeySpec pubSpec = new ECPublicKeySpec(point,ecSpec);
            PrivateKey privateKey = kf.generatePrivate(priSpec);
            PublicKey publicKey = kf.generatePublic(pubSpec);
            KeyPair keyPair = new KeyPair(publicKey,privateKey);
            return keyPair;
        //} catch (NoSuchAlgorithmException | NoSuchProviderException ex) {
        //}
        //return null;
    }**/

    /**
     * generate key pair to create eth wallet
     * 生成KeyPair , 用于创建钱包
     */
    public ECKeyPair generateKeyPair(String mnemonics) {
        long startTime = System.currentTimeMillis();
        // 1. we just need eth wallet for now
        AddressIndex addressIndex = BIP44
                .m()
                .purpose44()
                .coinType(60)
                .account(0)
                .external()
                .address(0);
        // 2. calculate seed from mnemonics , then get master/root key ; Note that the bip39 passphrase we set "" for common
        ExtendedPrivateKey rootKey = ExtendedPrivateKey.fromSeed(hex2Bytes(mnemonicToSeed(mnemonics)), Bitcoin.MAIN_NET);
        //Logger.i("mnemonics:" + mnemonics);
        //String extendedBase58 = rootKey.extendedBase58();
        //Logger.i("extendedBase58:" + extendedBase58);

        // 3. get child private key deriving from master/root key
        ExtendedPrivateKey childPrivateKey = rootKey.derive(addressIndex, AddressIndex.DERIVATION);
        //String childExtendedBase58 = childPrivateKey.extendedBase58();
        //Logger.i("childExtendedBase58:" + childExtendedBase58);


//        ExtendedPrivateKey key = ExtendedPrivateKey.deserializer().deserializer(childExtendedBase58);
        // 4. get key pair
        byte[] privateKeyBytes = Arrays.copyOfRange(
                childPrivateKey.extendedKeyByteArray(), 46, 78);
        //System.out.println("mnemonics:" + mnemonics);
        //System.out.println("*********************** success key " + bytes2Hex(privateKeyBytes));

        // we 've gotten what we need
        //String privateKey = new String(Arrays.copyOfRange(childPrivateKey.extendedKeyByteArray(), 46, 78));
        //new String(Hex.encode(childPrivateKey.extendedKeyByteArray()));

        //String address = Keys.getAddress(ECKeyPair.create(privateKeyBytes));
        //System.out.println("prikey:" + bytes2Hex(privateKeyBytes));
        /// System.out.println("pubkey:" +bytes2Hex(childPrivateKey.neuter().extendedKeyByteArray()));
        //System.out.println("address:" + address);
        ECKeyPair keyPair = ECKeyPair.create(privateKeyBytes);
        long endTime = System.currentTimeMillis();
        System.out.println("密钥生成算法运行时间为："+(endTime-startTime)+"ms");
        return keyPair;
    }

    public Flowable<HLWallet> importPrivateKey(Context context, String privateKey, String password) {
        if (privateKey.startsWith(Constant.PREFIX_16)) {
            privateKey = privateKey.substring(Constant.PREFIX_16.length());
        }
        Flowable<String> flowable = Flowable.just(privateKey);
        return flowable.flatMap(s -> {
            byte[] privateBytes = Hex.decode(s);
            ECKeyPair ecKeyPair = ECKeyPair.create(privateBytes);
            WalletFile walletFile = Wallet.createLight(password, ecKeyPair);
            HLWallet hlWallet = new HLWallet(walletFile);
            if (WalletManager.shared().isWalletExist(hlWallet.getAddress())) {
                return Flowable.error(new HLError(ReplyCode.walletExisted, new Throwable("Wallet existed!")));
            }
            WalletManager.shared().saveWallet(context, hlWallet);
            return Flowable.just(hlWallet);
        });
    }

    /**
     * web3j的导入Keystore方式,容易OOM
     */
    @Deprecated
    public Flowable<HLWallet> importKeystoreViaWeb3j(Context context, String keystore, String password) {
        return Flowable.just(keystore)
                .flatMap(s -> {
                    ObjectMapper objectMapper = new ObjectMapper();
                    WalletFile walletFile = objectMapper.readValue(keystore, WalletFile.class);
                    ECKeyPair keyPair = Wallet.decrypt(password, walletFile);
                    HLWallet hlWallet = new HLWallet(walletFile);

                    WalletFile generateWalletFile = Wallet.createLight(password, keyPair);
                    if (!generateWalletFile.getAddress().equalsIgnoreCase(walletFile.getAddress())) {
                        return Flowable.error(new HLError(ReplyCode.failure, new Throwable("address doesn't match private key")));
                    }

                    if (WalletManager.shared().isWalletExist(hlWallet.getAddress())) {
                        return Flowable.error(new HLError(ReplyCode.walletExisted, new Throwable("Wallet existed!")));
                    }
                    WalletManager.shared().saveWallet(context, hlWallet);
                    return Flowable.just(hlWallet);
                });
    }

    public Flowable<HLWallet> importKeystore(Context context, String keystore, String password) {
        return Flowable.just(keystore)
                .flatMap(s -> {
                    ObjectMapper objectMapper = new ObjectMapper();
                    WalletFile walletFile = objectMapper.readValue(keystore, WalletFile.class);
                    ECKeyPair keyPair = LWallet.decrypt(password, walletFile);
                    HLWallet hlWallet = new HLWallet(walletFile);

                    WalletFile generateWalletFile = Wallet.createLight(password, keyPair);
                    if (!generateWalletFile.getAddress().equalsIgnoreCase(walletFile.getAddress())) {
                        return Flowable.error(new HLError(ReplyCode.failure, new Throwable("address doesn't match private key")));
                    }

                    if (WalletManager.shared().isWalletExist(hlWallet.getAddress())) {
                        return Flowable.error(new HLError(ReplyCode.walletExisted, new Throwable("Wallet existed!")));
                    }
                    WalletManager.shared().saveWallet(context, hlWallet);
                    return Flowable.just(hlWallet);
                });
    }

//    public static void main(String[] args) {
//        System.out.println(this.generateMnemonics());
//    }


    // ---------------- singleton stuff --------------------------
    public static InitWalletManager shared() {
        return InitWalletManager.Holder.singleton;
    }

    private InitWalletManager() {

    }

    private static class Holder {

        private static final InitWalletManager singleton = new InitWalletManager();

    }
}
