package cn.gzhu.wallet;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashMap;
import java.util.Map;

/**
 * @author ASUS
 */
public class FileHelper {
    public static void saveUserInfo(Context context,String userName, String mnemonics, String password) {

        SharedPreferences sp = context.getSharedPreferences("data", Context.MODE_PRIVATE);
        SharedPreferences.Editor edit = sp.edit();

        edit.putString("userName",userName);
        edit.putString("mnemonics",mnemonics);
        edit.putString("password",password);

        edit.apply();

    }

    public static Map<String, String> getUserInfo(Context context) {

        SharedPreferences sp = context.getSharedPreferences("data", Context.MODE_PRIVATE);
        String userName = sp.getString("userName",null);
        String mnemonics = sp.getString("mnemonics",null);
        String password = sp.getString("password", null);

        Map<String, String> userMap = new HashMap<>(10);

        userMap.put("userName", userName);
        userMap.put("mnemonics", mnemonics);
        userMap.put("password",password);

        return userMap;

    }
}
