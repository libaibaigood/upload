package cn.gzhu.wallet.model;

import java.util.HashMap;

public class WalletStore {
    public HashMap<String, HLWallet> wallets = new HashMap<>();

    public WalletStore() {
    }
}
