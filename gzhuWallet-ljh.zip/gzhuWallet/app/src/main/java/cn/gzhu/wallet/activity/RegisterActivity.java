package cn.gzhu.wallet.activity;

import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.xiasuhuei321.loadingdialog.view.LoadingDialog;

import cn.gzhu.wallet.ActivityCollector;
import cn.gzhu.wallet.FileHelper;
import cn.gzhu.wallet.KeyStoreUtil;
import cn.gzhu.wallet.R;
import cn.gzhu.wallet.manager.InitWalletManager;
import cn.gzhu.wallet.model.HLWallet;
import cn.gzhu.wallet.stuff.HLError;
import cn.gzhu.wallet.stuff.HLSubscriber;
import cn.gzhu.wallet.stuff.ScheduleCompat;
import io.reactivex.Flowable;

/**
 * @author ASUS
 */
public class RegisterActivity extends BaseActivity {

    private Button registerButton;
    private Context mContext;
    private String userName;
    private String password;
    private String rePassword;

    private EditText uName;
    private EditText pwd;
    private EditText rePwd;

    public void toastMessage(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        mContext = this;

        uName = findViewById(R.id.input_username);
        pwd = findViewById(R.id.input_password);
        rePwd = findViewById(R.id.input_rePassword);

        registerButton = findViewById(R.id.register_button);
        registerButton.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                userName = uName.getText().toString().trim();
                KeyStoreUtil.get().generateKey(mContext,userName);
                password = KeyStoreUtil.get().encrypt(pwd.getText().toString().trim(),userName);
                rePassword = KeyStoreUtil.get().encrypt(rePwd.getText().toString().trim(),userName);

                if(TextUtils.isEmpty(userName)){
                    toastMessage("请输入用户名!");
                }else if(TextUtils.isEmpty(password)){
                    toastMessage("请输入密码!");
                }else if (TextUtils.isEmpty(rePassword)){
                    toastMessage("请再次输入你的密码!");
                }else if(!KeyStoreUtil.get().decrypt(password,userName).equals(KeyStoreUtil.get().decrypt(rePassword,userName))){
                    toastMessage("前后输入密码不一致!");
                }else {
                    createWallet();
                }
            }
        }));
    }

    private void createWallet() {

        LoadingDialog ld = new LoadingDialog(this);
        ld.setLoadingText("加载中")
                .setSuccessText("加载成功")
                //.setFailedText("加载失败")
                .setInterceptBack(false)
                .setLoadSpeed(LoadingDialog.Speed.valueOf("SPEED_TWO"))
                .closeSuccessAnim()
                .setRepeatCount(2)
                .setShowTime(1000)
                .show();


        String mnemonics = InitWalletManager.shared().generateMnemonics();
        Flowable
                .just(password)
                .map(s -> mnemonics)
                .flatMap(s -> InitWalletManager.shared().generateWallet(mContext,KeyStoreUtil.get().decrypt(password,userName),s))
                .compose(ScheduleCompat.apply())
                .subscribe(new HLSubscriber<HLWallet>(mContext,true) {
                    @Override
                    protected void success(HLWallet data) {
                        FileHelper.saveUserInfo(mContext,userName,mnemonics,password);
                        ld.loadSuccess();
                        new Thread() {
                            @Override
                            public void run() {
                                super.run();
                                try {
                                    Thread.sleep(1100);
                                } catch (InterruptedException e) {
                                    e.printStackTrace();
                                }
                                navigateTo(NavigationActivity.class);
                                ActivityCollector.finishOneActivity(MainActivity.class.getName());
                                ld.close();
                                finish();
                            }
                        }.start();
                    }
                    @Override
                    protected void failure(HLError error) {
                        toastMessage("创建钱包失败，请重新创建!");
                    }
                });
    }
}
