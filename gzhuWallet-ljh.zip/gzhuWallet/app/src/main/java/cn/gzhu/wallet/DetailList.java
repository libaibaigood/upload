package cn.gzhu.wallet;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.LinkedList;

import cn.gzhu.wallet.activity.TransferInfoActivity;

/**
 * @author ASUS
 */
public class DetailList extends BaseAdapter {

    private Context mContext;
    private LinkedList<Data> mData;

    public DetailList() {}

    public DetailList(LinkedList<Data> mData, Context mContext) {
        this.mData = mData;
        this.mContext = mContext;


    }

    public void add(Data data) {
        if (mData == null) {
            mData = new LinkedList<>();
        }
        mData.add(data);
        notifyDataSetChanged();
    }


    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder = null;
        if(convertView == null){
            convertView = LayoutInflater.from(mContext).inflate(R.layout.detail_list,parent,false);
            holder = new ViewHolder();
            holder.txt_content1 = (TextView) convertView.findViewById(R.id.num1);
            holder.txt_content2 = (TextView) convertView.findViewById(R.id.num2);
            holder.txt_content3 = (TextView) convertView.findViewById(R.id.num3);
            holder.toTransferInfo = convertView.findViewById(R.id.to_transferInfo);
            convertView.setTag(holder);
        }else{
            holder = (ViewHolder) convertView.getTag();
        }
        holder.txt_content1.setText(mData.get(position).getNum1());
        holder.txt_content2.setText(mData.get(position).getNum2());
        holder.txt_content3.setText(mData.get(position).getNum3());
        holder.toTransferInfo.setOnClickListener(new View.OnClickListener(){

            @Override
                    public void onClick(View v){
                Intent intent= new Intent(mContext, TransferInfoActivity.class);
               String url = "https://ropsten.etherscan.io/tx/0xe2294e2973d3d96ebd29326c395e5901d8879081e291931b25164b11f49b59ed";
               // String url = "https://www.baidu.com/";
                intent.putExtra("url",url);
                mContext.startActivity(intent);
            }
        });
        return convertView;
    }

    private class ViewHolder{

        public TextView txt_content1;
        public TextView txt_content2;
        public TextView txt_content3;
        public View toTransferInfo;
//        TextView getTxt_content1;
//        TextView getTxt_content2;
//        TextView getTxt_content3;
    }
}
