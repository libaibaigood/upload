package cn.gzhu.wallet.activity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.Selection;
import android.text.Spannable;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Map;

import cn.gzhu.wallet.FileHelper;
import cn.gzhu.wallet.KeyStoreUtil;
import cn.gzhu.wallet.R;

/**
 * @author ASUS
 */
public class CheckActivity extends BaseActivity {

    private Button mSwitchButton;
    private EditText mPasswordEditText;
    private Button checkPassword;
    private boolean isHidden=false;
    private TextView btn_exit;
    Context context;
    public void toastMessage(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check);
        context = this;
        checkPassword = findViewById(R.id.button);
        mSwitchButton=(Button) findViewById(R.id.btn_show);
        mPasswordEditText=(EditText) findViewById(R.id.check_password);
        mPasswordEditText.setTransformationMethod(PasswordTransformationMethod.getInstance());
        btn_exit = findViewById(R.id.exit);
        btn_exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new AlertDialog.Builder(context)
                        .setTitle("存储权限不可用")
                        .setMessage("由于支付宝需要获取存储空间，为你存储个人信息；\n否则，您将无法正常使用支付宝")
                        .setPositiveButton("立即开启", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                FileHelper.saveUserInfo(context,"","","");
                                navigateTo(MainActivity.class);
                                finish();
                            }
                        })
                        .setNegativeButton("取消", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                finish();
                            }
                        }).setCancelable(false).show();

            }
        });
        checkPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Map userInfo = FileHelper.getUserInfo(context);
                String pwd = mPasswordEditText.getText().toString().trim();
                String password = (String) userInfo.get("password");
                if(pwd.equals(KeyStoreUtil.get().decrypt(password,(String) userInfo.get("userName")))){
                    navigateTo(NavigationActivity.class);
                    finish();
                }else {
                    toastMessage("密码错误");
                }
            }
        });
        init();
    }
    private void init(){

        mSwitchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isHidden) {
                    //设置EditText文本为可见的
                    mPasswordEditText.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                } else {
                    //设置EditText文本为隐藏的
                    mPasswordEditText.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }
                isHidden = !isHidden;
                mPasswordEditText.postInvalidate();
                //切换后将EditText光标置于末尾
                CharSequence charSequence = mPasswordEditText.getText();
                if (charSequence instanceof Spannable) {
                    Spannable spanText = (Spannable) charSequence;
                    Selection.setSelection(spanText, charSequence.length());
                }

            }
        });
    }
}