package cn.gzhu.wallet.model;

/**
 * @author ASUS
 */
public class SwitchWalletEvent {
}
