package cn.gzhu.wallet.stuff;

public interface ReplyCode {
    int failure = -1;

    int walletExisted = 10;

    int invokeException = -2;
}
